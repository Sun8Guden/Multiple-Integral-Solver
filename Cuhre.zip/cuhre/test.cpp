#include <iostream>
#include <array>
#include <vector>
#include <cmath>
#include <iomanip>
#include "Region.hpp"
#include "Integration.hpp"
#include <chrono>

int main(){
    std::array<double, 2> center{1.0, 1.0};
    std::array<double, 2> width{2.0, 2.0};
    auto foo = [](const std::array<double, 2>& input){
        double val = std::exp(-(input.at(0) * input.at(0) + input.at(1) * input.at(1)));
        return val;
    };

    auto parallel = IntegrationStrategy::parallel;

    Region<2> cur_region(center, width);
    double estimated_error{0.0};
    int num_func_eval{0};

    auto start = std::chrono::steady_clock::now();
    auto integral = Integration<2>::integrate(foo, cur_region, estimated_error, num_func_eval, parallel, 1e-12, 500, 50000);
    auto end = std::chrono::steady_clock::now();
    std::cout << "Elapsed time: " << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() \
        << " microseconds." <<std::endl;
    std::cout << std::setprecision(15)<< "The integral is " << integral << ", with an estimated error " << estimated_error << " after " << num_func_eval << " function calls\n";


    start = std::chrono::steady_clock::now();
    integral = Integration<2>::integrate(foo, cur_region, estimated_error, num_func_eval, IntegrationStrategy::serial,  1e-12, 500, 50000);
    end = std::chrono::steady_clock::now();
    std::cout << "Elapsed time: " << std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() \
        << " microseconds." <<std::endl;
    std::cout << std::setprecision(15)<< "The integral is " << integral << ", with an estimated error " << estimated_error << " after " << num_func_eval << " function calls\n";

}

// class Try{
//     public:
//     Try():weights(std::vector<std::vector<double> >(6, std::vector<double>(5, 0.0))){}
//     std::vector<std::vector<double> > weights;
//     int bb{3+5};
// };
// int main(){
//     Try aa;
//     std::cout << aa.bb;
//     return 0;
// }



















// ** TESTING STATIC - CONST - CONSTEXPR, etc.
// template<int N>
// class IntArray{
//     std::array<int, N> m_int_array;
//     int number_of_initialization{0};

//     public:
//     IntArray(){
//         m_int_array.fill(N);
//         number_of_initialization++;
//         std::cout << "\n The number of initialization is " << \
//             number_of_initialization << std::endl; 
//     }
//     void get_info() const {
//         for (int i=0; i<N; i++){
//             std::cout << m_int_array.at(i) << ", ";
//         }
//     }

//     static const IntArray& getInstance() {
//         static const IntArray intArray;
//         return intArray;
//     }

// };

// template<int N>
// class UseIntArray{

//     public:
//     int array_idx;
    
//     // This is called initializtion on first use.
//     static const IntArray<N>& intArrayInstrance(){
//         static const IntArray<N> cur = IntArray<N>::getInstance();
//         return cur;
//     }
    
//     UseIntArray(int idx):array_idx(idx){}
//     ~UseIntArray(){}

// };

// int main(){
//     UseIntArray<2>::intArrayInstrance().get_info();
//     UseIntArray<2>::intArrayInstrance().get_info();
//     UseIntArray<2>::intArrayInstrance().get_info();
//     UseIntArray<3>::intArrayInstrance().get_info();
//     UseIntArray<3>::intArrayInstrance().get_info();
//     UseIntArray<3>::intArrayInstrance().get_info();
//     UseIntArray<3>::intArrayInstrance().get_info();
//     UseIntArray<3>::intArrayInstrance().get_info();



//     return 0;

// }



// *** TESTING PRIORITY-QUEUE ***
// class IntType {
// public:
//     int m_value;
//     IntType(int x_): m_value(x_){}

//     friend bool operator<(const IntType& a, const IntType& b);
// };


// bool operator<(const IntType& a, const IntType& b){
//         return a.m_value < b.m_value;
//     };


// int main(){

//     std::priority_queue<IntType, std::vector<IntType>> my_heap;
//     my_heap.push( IntType(1) );
//     my_heap.push( IntType(5) );
//     my_heap.push( IntType(3) );
//     std::cout << my_heap.top().m_value << std::endl;
//     my_heap.push( IntType(11) );
//     std::cout << my_heap.top().m_value << std::endl;

// }


// *** TESTING OMP ***
// #include <omp.h>
// int main(){
//     int numThread = omp_get_max_threads();
//     std::cout << "Outside the construct, the number of threads is " << numThread << std::endl;

//     #pragma omp parallel
//     {
//         int threadIndex = omp_get_num_threads();
//         std::cout << "Inside the construct: " << threadIndex << std::endl;
//         // #pragma omp critical
//     }
//     return 0;
// }