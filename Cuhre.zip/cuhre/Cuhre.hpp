#pragma once
#include <iostream>
#include <vector>
#include "Region.hpp"
#include "Rule.hpp"



